#!/bin/bash

no=10
10=no
vehicle=Bus
n=10
echo $vehicle
echo $n
