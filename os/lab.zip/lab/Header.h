#ifndef HEADER_H
#define HEADER_H

int* take_input(int l);
int * reverse(int* a , int l);
void display(int *a , int l);










#endif