#include <stdio.h>

int main()
{
	int opt;
	scanf("%d", &opt);
	switch(opt)
	{
		case 1 : 
			printf("one\n");
			break;
		case 2 : 
			printf("two\n");
			break;
		case 3 : 
			printf("three\n");
			break;
		case 4 : 
			printf("four\n");
			break;
		case 5 : 
			printf("five\n");
			break;
	}
	printf("hello world\n");
}
