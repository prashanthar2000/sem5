#include <stdio.h>

int main()
{
	char item[20];
	while(scanf("%s", item) != EOF)
	{
		printf("%s\n", item);
	}
	
}
