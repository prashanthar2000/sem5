#ifndef RE_H
#define RE_H
// successful : 1
// failure : 0
int match(char *pat, char *text);
#endif

